CREATE PROCEDURE insert_feature()
  begin
	declare i int;
	set i = 1;
	while i < 40 do
		insert ignore into company_feature(company_id, feature_id)
        values(floor(rand()*19 + 1), floor(rand()*5 + 1));
		set i = i + 1;
	end while;
end;

